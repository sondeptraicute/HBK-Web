function openNav() {
    document.getElementById("myNav").style.height = "30%";
}

function closeNav() {
    document.getElementById("myNav").style.height = "0%";
}