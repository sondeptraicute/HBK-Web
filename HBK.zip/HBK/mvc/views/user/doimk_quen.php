<main class="main_login mt-4 d-flex justify-content-center">
    <div class="form__login">
        <form action="" class="grid-column mt-3" method="post">
            <div class="input__form__icon card ">
                <i class="far fa-eye"></i>
                <input class=" nhap_input_login" type="email" name="email" placeholder="Nhập mail">
            </div>
            <div class="input__form__icon card ">
                <i class="far fa-eye"></i>
                <input class=" nhap_input_login" type="password" name="pass" placeholder="Mật khẩu mới của bạn">
            </div>
            <div class="input__form__icon card ">
                <i class="far fa-eye"></i>
                <input class=" nhap_input_login" type="password" name="pass2" placeholder="Nhập lại mật khẩu">
            </div>
            <div class="input__form__icon card ">
                <i class="far fa-eye"></i>
                <input class=" nhap_input_login" type="text" name="code" placeholder="Nhập mã gửi về mail">
            </div>
            <input type="submit" name="doi_mk_quen" value="Đổi mật khẩu" class="dang_nhap_dk btn">
        </form>
    </div>
</main>