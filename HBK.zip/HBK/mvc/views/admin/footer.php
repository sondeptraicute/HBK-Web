</div>
<script src="../public/js/check.js">
</script>
<script src="../public/js/editor.js">
</script>
<script src="../public/js/atribute.js">
</script>
</body>

</html>