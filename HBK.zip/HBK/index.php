<?php
header("location:mvc/controllers/user.php"); 
?>